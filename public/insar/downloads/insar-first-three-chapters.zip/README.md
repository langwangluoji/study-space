# InSAR 前三章离线讲义

[从课程总览开始](讲义/course-insar.md)。使用支持 LaTeX 数学公式的 Markdown 编辑器阅读；配图已转换为相对路径。线上地址：https://langwangluoji.github.io/study-space/course-insar.html

范围：课堂微波遥感基础、SAR成像原理、SAR图像特征及解译。完整教师PDF与教材不包含在包内；交互动画通过标明的联网链接打开，期末关键总结见讲义/review-insar.md。原图署名与页码见讲义/insar-sources.md，均为有限教学引用；整理文字与自绘图供个人学习。
