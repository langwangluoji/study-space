
<a id="光学复习关键总结"></a>
<a id="应能说明的条件"></a>
<a id="教材修订后的自检"></a>

# 光学考试复习：概念与公式精简版

## 1. 统一记号

实场取 $\operatorname{Re}[\mathbf E_0e^{i(\mathbf k\cdot\mathbf r-\omega t)}]$，$\mathbf E_0$ 为峰值复振幅。$\nu$ 用Hz，$\omega=2\pi\nu$；$\lambda_0$ 为真空波长，透明介质中 $\lambda=\lambda_0/n$。$\varepsilon,\mu$ 是绝对量，带下标 $r$ 的参数是相对量。被动吸收介质取 $\widetilde n=n_r+i\kappa$。$e>0$ 为元电荷大小，$m$ 为电子质量。数值计算常用 $c\simeq3.00\times10^8\,\mathrm{m/s}$、$h\simeq6.626\times10^{-34}\,\mathrm{J\,s}$、$k_B\simeq1.381\times10^{-23}\,\mathrm{J/K}$；热学公式中的 $T$ 用K。

## 2. 波动、电磁场与干涉

### 相位与波形

同一时刻相位相同的点构成波面。固定相位后求位置对时间的导数，得到相速度；固定时刻沿指定方向比较相位，得到空间周期。

$$
\psi=f(x-vt)+g(x+vt),\qquad
\partial_x^2\psi=\frac1{v^2}\partial_t^2\psi,
\qquad k=\frac{2\pi}{\lambda},\quad v_p=\frac\omega k=\lambda\nu.
$$

前一项沿正 $x$ 方向传播，后一项沿负方向传播。波前为平面时，$\mathbf k$ 沿波前法线；普通空间频率向量为 $\mathbf f=\mathbf k/(2\pi)$。沿单位方向 $\widehat{\mathbf l}$ 的正周期为

$$
d=\frac{2\pi}{|\mathbf k\cdot\widehat{\mathbf l}|}
=\frac{\lambda}{|\cos\vartheta|}.
$$

截线垂直 $\mathbf k$ 时相位沿线不变。均匀无损介质的球面波振幅随 $1/r$ 衰减，柱面波远场振幅随 $1/\sqrt r$ 衰减，分别对应 $I\propto1/r^2$ 和 $I\propto1/r$。

### 电磁场与能流

均匀、各向同性、无源介质中的单频传播平面波满足

$$
\mathbf k\cdot\mathbf E_0=0,\qquad
\mathbf B_0=\frac{\mathbf k\times\mathbf E_0}{\omega},\qquad
k^2=\omega^2\varepsilon\mu.
$$

对均匀、无损、正实 $\varepsilon,\mu$ 的介质，$Z=\sqrt{\mu/\varepsilon}$，平均能流为

$$
\langle\mathbf S\rangle=\frac12\operatorname{Re}(\mathbf E_0\times\mathbf H_0^*),
\qquad I=\frac{|\mathbf E_0|^2}{2Z}.
$$

非磁透明介质还可写 $I=n\varepsilon_0c|\mathbf E_0|^2/2$。线偏振的电场沿固定方向振动，圆偏振和椭圆偏振同样可以是横向平面波。

### 相干与干涉

相干性描述场的相位相关性。对共线、同阻抗的两束同频波，场相加后求平均强度：

$$
I=I_1+I_2+\frac1Z\operatorname{Re}(\mathbf E_{01}\cdot\mathbf E_{02}^*).
$$

同偏振、完全相干时，$I=I_1+I_2+2\sqrt{I_1I_2}\cos\delta$；可见度 $V=2\sqrt{I_1I_2}/(I_1+I_2)$。反相且等幅时完全相消。正交偏振使该检测方式的交叉项为零；统计不相干则由随机相位平均消去交叉项。

两频率相差 $\Delta\nu$ 时，拍频周期为 $1/|\Delta\nu|$，能否观察取决于探测带宽和积分时间。持续时间为 $\tau$ 的矩形波列，其普通频率谱首零偏移为 $1/\tau$；这一尺度随包络形状改变。

推导与例题：[波动和电磁理论](optics-waves.md)。

## 3. 辐射量、热辐射与光源

### 辐射量

| 物理量 | 定义 | 单位 |
| --- | --- | --- |
| 通量 | $\Phi=dQ/dt$ | W |
| 辐照度、出射度 | $E_e=d\Phi_{\rm in}/dA$，$M=d\Phi_{\rm out}/dA$ | $\mathrm{W\,m^{-2}}$ |
| 辐射强度 | $I_e=d\Phi/d\Omega$ | $\mathrm{W\,sr^{-1}}$ |
| 辐亮度 | $L_e=d^2\Phi/(dA\cos\theta\,d\Omega)$ | $\mathrm{W\,m^{-2}\,sr^{-1}}$ |

无衰减点源的接收面辐照度为 $E_e=I_e\cos\theta/r^2$；整个出射半球辐亮度均匀时，$M=\pi L_e$。被动样品的谱吸收率为吸收通量除以入射通量，取值在0与1之间。

### 黑体公式

黑体在各波长完全吸收；热平衡下，同方向、同偏振的谱发射率等于谱吸收率。真空黑体的每Hz谱能量密度与谱出射度为

$$
u_\nu=\frac{8\pi h\nu^3}{c^3}\frac1{e^{h\nu/(k_BT)}-1},
\qquad M_\nu=\frac c4u_\nu.
$$

$u_\nu$ 的单位为 $\mathrm{J\,m^{-3}\,Hz^{-1}}$，$M_\nu$ 为 $\mathrm{W\,m^{-2}\,Hz^{-1}}$。改变谱变量需保留同一谱带的能量：

$$
M_\lambda=M_\nu(c/\lambda_0)\frac c{\lambda_0^2}
=\frac{2\pi hc^2}{\lambda_0^5}\frac1{e^{hc/(\lambda_0k_BT)}-1}.
$$

| 关系 | 公式与含义 |
| --- | --- |
| 总出射度 | $M=\sigma_{\rm SB}T^4$，$\sigma_{\rm SB}=5.670374419\times10^{-8}\,\mathrm{W\,m^{-2}K^{-4}}$ |
| 每波长谱峰 | $\lambda_{\max}T=2.897771955\times10^{-3}\,\mathrm{m\,K}$ |
| 长波、低频极限 | $h\nu\ll k_BT$ 时，$u_\nu\simeq8\pi\nu^2k_BT/c^3$（Rayleigh–Jeans） |
| 短波、高频极限 | $h\nu\gg k_BT$ 时，Planck分母近似为 $e^{h\nu/(k_BT)}$（Wien） |

当波长以米为单位时，$M_\lambda$ 的单位是 $\mathrm{W\,m^{-2}\,m^{-1}}$；每微米谱密度的数值为每米数值的 $10^{-6}$。频率谱和波长谱的峰对应不同的谱分配；用各自谱函数求极值。总发射功率还需乘面积，净辐射交换还需计入环境的入射辐射。

### 发光机制与谱

| 机制 | 识别概念或公式 |
| --- | --- |
| 电偶极辐射 | 小源真空远区，平均角分布 $\propto\sin^2\theta$；简谐峰值偶极矩 $p_0$ 的平均总功率 $\langle P\rangle=\omega^4p_0^2/(12\pi\varepsilon_0c^3)$ |
| 同步辐射 | 相对论电子作曲线运动，辐射集中在速度切线附近 |
| 轫致辐射 | 电子动能转为连续光谱；初动能可忽略、经电压 $U$ 加速时，$h\nu_{\max}=eU$、$\lambda_{\min}=hc/(eU)$ |
| 切伦科夫辐射 | 均匀、各向同性、近无损介质，$\beta n_r(\omega)>1$，$\cos\theta=1/(\beta n_r)$；其中 $\beta=v/c$，$\theta$ 为波矢与粒子速度夹角，阈值比较粒子速度与相速度 |
| 能级跃迁 | $h\nu=E_u-E_l$；原子常见线谱，分子振转结构可形成密集带谱，特征X射线由壳层能级差决定 |

玻尔氢原子近似下，$E_n\simeq-13.6\,\mathrm{eV}/n^2$；发射谱满足 $1/\lambda_0=R_H(1/n_f^2-1/n_i^2)$，$n_i>n_f$。

真空光子满足 $E_\gamma=h\nu=hc/\lambda_0$、$p=h/\lambda_0$，$hc\simeq1239.84\,\mathrm{eV\,nm}$。原子能级与黑体模式的量子平均能量需要量子理论输入。

推导与例题：[非相干辐射与热辐射](optics-incoherent.md)。

## 4. 激光、线宽与自由电子激光

### 跃迁、反转和寿命

$A_{21}$ 表示单粒子自发跃迁率，单位 $\mathrm{s^{-1}}$；$B_{12}u_\nu$ 和 $B_{21}u_\nu$ 分别表示受激吸收和受激辐射的单粒子速率。$B$ 按自由空间、各向同性非偏振总能量的每Hz谱密度定义。$N_i$ 是能级 $i$ 的布居，$g_i$ 是简并度；下列第三式采用正温热平衡：

$$
g_1B_{12}=g_2B_{21},\qquad
\frac{A_{21}}{B_{21}}=\frac{8\pi h\nu^3}{c^3},\qquad
\frac{N_2}{N_1}=\frac{g_2}{g_1}e^{-h\nu/(k_BT)}.
$$

净受激增益要求 $N_2/g_2>N_1/g_1$。等简并闭合二能级的连续光泵浦，设 $W$ 为每粒子的泵浦受激跃迁率、$N=N_1+N_2$，在布居速率模型的稳态满足 $N_2/N=WT_1/(1+2WT_1)<1/2$；三能级和四能级利用其他能级的泵浦与弛豫建立反转。

撤去泵浦并忽略受激过程，上能级布居按自发过程衰减。以 $T_1$ 表示布居寿命，$T_2$ 表示相干衰减时间，相应的布居与自然线宽为

$$
N_2(t)=N_2(0)e^{-t/T_1},\qquad
\Delta\nu_{\rm FWHM}=\frac1{2\pi T_1}=\frac1{\pi T_2}.
$$

线宽等式限于上能级单纯自发衰减、下能级稳定的自然Lorentz线型，此时 $T_2=2T_1$。额外退相干、碰撞和多普勒效应改变线宽；多条辐射通道时 $1/\tau_{\rm rad}=\sum_jA_{2j}$。

### 阈值与模式

增益补偿损耗决定振荡是否增长，往返相位自洽决定允许频率。均匀增益填满长度 $L$ 的线性腔，在阈值处满足：

$$
R_1R_2e^{2(g-\alpha_i)L}=1,
\qquad g_{\rm th}=\alpha_i+\frac1{2L}\ln\frac1{R_1R_2}.
$$

$g,\alpha_i$ 是强度每长度系数，$R_i$ 是功率反射率。忽略镜面附加相位时，$2nL=q\lambda_0$；纵模间隔 $\mathrm{FSR}\simeq c/(2n_gL)$，其中 $n_g=n+\omega\,dn/d\omega$。增益带宽内的允许模数约为带宽除以FSR，实际振荡还受阈值和模式竞争控制。横模描述横截面场分布。

相干性、方向性和谱宽分别描述不同性质。变换极限Gaussian脉冲的强度半高全宽满足 $\Delta t\Delta\nu\simeq0.441$。倍频由非线性极化产生，还需相位匹配以有效累积。

### 自由电子激光

电子在波荡器中横向运动，与光场交换能量并形成微群聚。平面波荡器采用峰值磁场定义：

$$
K=\frac{eB_u\lambda_u}{2\pi mc}
\simeq0.934B_u[\mathrm T]\lambda_u[\mathrm{cm}],
\qquad
\lambda_s\simeq\frac{\lambda_u}{2s\gamma_e^2}
\left(1+\frac{K^2}{2}+\gamma_e^2\theta^2\right).
$$

其中 $\lambda_u$ 为波荡周期，$\gamma_e=(1-v^2/c^2)^{-1/2}$，$\theta$ 为相对波荡器平均轴线的观察角。这是超相对论、小角近似，$s$ 为谐波次数；轴上允许谐波还取决于平面波荡器的对称性。相同单电子振幅、同一观察模下，$b=N^{-1}\sum_j e^{-i\psi_j}$、$I_N=N^2|b|^2I_1$；独立均匀随机相位满足 $\langle|b|^2\rangle=1/N$，平均强度为 $NI_1$。SASE由散粒噪声启动，种子方案利用已有相干光控制辐射。

推导与例题：[相干辐射与激光](optics-laser.md)。

## 5. 介质响应、吸收、色散与光线

### 从电子运动到复折射率

线性束缚电子的Lorentz模型为 $m\ddot x+m\gamma\dot x+m\omega_0^2x=-eE$。取负时间因子，稳态响应为

$$
\chi(\omega)=\frac{\omega_p^2}{\omega_0^2-\omega^2-i\gamma\omega},
\quad \omega_p^2=\frac{N_ee^2}{m\varepsilon_0},\quad
\widetilde n^2=\varepsilon_r\mu_r.
$$

式中 $N_e$ 是电子数密度。非磁介质有 $n_r^2-\kappa^2=1+\chi'$、$2n_r\kappa=\chi''$。在 $|\chi|\ll1$ 时可用 $\widetilde n\simeq1+\chi/2$。取 $\omega_0=0$ 得Drude自由载流子模型。

### 吸收与透射

$$
E(z)\propto e^{-\omega\kappa z/c},\qquad
I(z)=I(0)e^{-\alpha z},\qquad
\alpha=\frac{2\omega\kappa}{c}=\frac{4\pi\kappa}{\lambda_0}.
$$

$I(0)$ 取介质内部起始强度；外部入射到透射的计算还需界面因素。独立、稀薄吸收粒子给出 $\alpha=N\sigma_a$，此处 $N$ 为吸收粒子数密度，单位 $\mathrm{m^{-3}}$。球面几何扩散、散射和无损倏逝场也可使某方向的场或束流变弱，吸收则对应材料获得能量。

### 色散与光程

| 概念 | 公式和条件 |
| --- | --- |
| Cauchy近似 | $n(\lambda_0)=A+B/\lambda_0^2+C/\lambda_0^4+\cdots$；透明、远离共振的频段，波长单位决定系数单位 |
| 正常、反常色散 | 正常 $dn/d\lambda_0<0$，反常 $dn/d\lambda_0>0$ |
| 群速度 | $v_g=c/n_g$，$n_g=n_r+\omega\,dn_r/d\omega$；适用于畸变可忽略的窄带波包 |
| 光程与相位 | $\mathcal L=\int n\,ds$，$\phi=k_0\mathcal L$；静止、透明、各向同性的几何光学模型 |
| Fermat原理 | $\delta\int n\,ds=0$；端点固定，取驻值 |
| 光线方程 | $d(n\widehat{\mathbf t})/ds=\nabla n$；平滑介质中光线向较高折射率一侧弯曲 |

色散介质中的相位光程与群延迟分别用 $n$ 和 $n_g$。强吸收区的脉冲会变形，群速度与信息前沿速度需分别讨论。无自由电荷的非均匀介质满足 $\nabla\cdot\mathbf D=0$，电场散度由介质梯度决定。

推导与例题：[光的传播与介质响应](optics-propagation.md)。

## 6. 解题时从哪里开始

| 题型 | 起始方程与步骤 |
| --- | --- |
| 传播方向、波面和周期 | 写总相位，固定相位求速度，或沿指定方向求相位差 |
| 合振幅、干涉和拍频 | 写复场之和，再取模平方或Poynting平均，按探测时间平均交叉项 |
| 辐射量、黑体与谱峰 | 先确定面积、立体角及谱变量，再积分、变换变量或求极值 |
| 寿命和线宽 | 布居指数衰减给场幅衰减，再作Fourier变换并按强度谱取FWHM |
| 激光阈值、纵模与FEL共振 | 分别列往返功率、往返相位或相邻周期的滑移条件 |
| 介质吸收和色散 | 由振子稳态解求 $\chi$，再求复折射率、衰减或频率导数 |
| 光程与弯曲 | 写 $\int n\,ds$，利用驻值或光线方程判断路径 |

较完整的参数表见[公式总表](optics-formulas.md)，逐题练习见[原作业与综合自检](optics-exercises.md)。需要重建推导时，从[课程学习版](optics-learning.md)进入对应章节。

<a id="复习主线"></a>
